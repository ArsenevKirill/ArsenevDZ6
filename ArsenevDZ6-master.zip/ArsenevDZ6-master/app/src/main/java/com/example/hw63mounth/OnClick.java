package com.example.hw63mounth;

public interface OnClick {
    void ocClick (Model model);
}
